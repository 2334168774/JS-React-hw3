import React, { Component } from 'react'

export default class Start extends Component {
    render() {
        return (
            <div>
                Start
            </div>
        )
    }
}
